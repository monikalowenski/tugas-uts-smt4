<!DOCTYPE html>
<html>
<head>
    <title>NewZakat</title>
    <style>
        h1 {
            text-align: center;
            margin-bottom: 50px;
        }
        button {
            font-size: 24px;
            padding: 10px 20px;
        }
    </style>
</head>
<body>
    <h1> TUGAS UTS PAK PUNGKY</h1>
    <p style="text-align: center;">NAMA : MONIKA LOWENSKI<br>NIM  : 2222105196<br>Kelas   : 2TI04<br>Pemrograman Berorientasi Objek<br>untuk username dan password monika123 dan 12345678</p>
    <?php
    require_once 'connect.php';
    ?>
    <a href="homepage/"><button> HALAMAN UTAMA</button></a>
</body>
</html>