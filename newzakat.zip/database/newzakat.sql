-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2024 at 08:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newzakat`
--

-- --------------------------------------------------------

--
-- Table structure for table `donatur`
--

CREATE TABLE `donatur` (
  `ID_donatur` int(11) NOT NULL,
  `Nama` varchar(50) DEFAULT NULL,
  `Alamat` varchar(50) DEFAULT NULL,
  `Jenis_zakat` varchar(50) DEFAULT NULL,
  `Jumlah` varchar(5) DEFAULT NULL,
  `Tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donatur`
--

INSERT INTO `donatur` (`ID_donatur`, `Nama`, `Alamat`, `Jenis_zakat`, `Jumlah`, `Tanggal`) VALUES
(13348, 'hadid', 'kelapadua, depok', 'beras', '12kg', '2024-04-01'),
(13349, 'ade', 'cijantra, pagedangan', 'emas', '2gr', '2024-04-02'),
(13350, 'erik', 'cililitan, jaktim', 'beras ', '15kg', '2024-04-01'),
(13351, 'tata', 'kelapadua, tangerang', 'beras', '6kg', '2024-03-07'),
(13352, 'tiffany', 'islamic village, tangerang', 'beras', '9kg', '2024-04-02');

--
-- Triggers `donatur`
--
DELIMITER $$
CREATE TRIGGER `riwayat_insert` AFTER INSERT ON `donatur` FOR EACH ROW BEGIN
    DECLARE last_id INT;

    -- Mendapatkan nilai terakhir dari ID_transaksi
    SELECT IFNULL(MAX(ID_transaksi), 33000) INTO last_id FROM transaksi;

    -- Menetapkan nilai ID_transaksi untuk baris baru
    INSERT INTO transaksi (ID_transaksi, ID_donatur, Jumlah, Status_pembayaran, Tanggal)
    VALUES (last_id + 1, NEW.ID_donatur, NEW.Jumlah, 'Belum Lunas', NEW.Tanggal);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `riwayat_update` AFTER UPDATE ON `donatur` FOR EACH ROW BEGIN
    DECLARE last_id INT;

    -- Mendapatkan nilai terakhir dari ID_transaksi
    SELECT IFNULL(MAX(ID_transaksi), 33000) INTO last_id FROM transaksi;

    -- Menetapkan nilai ID_transaksi untuk baris baru
    INSERT INTO transaksi (ID_transaksi, ID_donatur, Jumlah, Status_pembayaran, Tanggal)
    VALUES (last_id + 1, NEW.ID_donatur, NEW.Jumlah, 'Belum Lunas', NEW.Tanggal);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `penerima`
--

CREATE TABLE `penerima` (
  `ID_penerima` int(11) NOT NULL,
  `Nama_penerima` varchar(100) DEFAULT NULL,
  `Alamat` varchar(100) DEFAULT NULL,
  `ID_donatur` int(11) DEFAULT NULL,
  `Zakat_diterima` varchar(100) DEFAULT NULL,
  `Jumlah_diterima` varchar(100) DEFAULT NULL,
  `Jumlah_jiwa` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penerima`
--

INSERT INTO `penerima` (`ID_penerima`, `Nama_penerima`, `Alamat`, `ID_donatur`, `Zakat_diterima`, `Jumlah_diterima`, `Jumlah_jiwa`) VALUES
(22001, 'Nikol', 'Bandung', NULL, 'Beras', '5Kg', '3'),
(22002, 'alex', 'cibubur, bekasi', NULL, 'beras', '18kg', '6 jiwa');

-- --------------------------------------------------------

--
-- Table structure for table `seq_id_transaksi`
--

CREATE TABLE `seq_id_transaksi` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) UNSIGNED NOT NULL,
  `cycle_option` tinyint(1) UNSIGNED NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seq_id_transaksi`
--

INSERT INTO `seq_id_transaksi` (`next_not_cached_value`, `minimum_value`, `maximum_value`, `start_value`, `increment`, `cache_size`, `cycle_option`, `cycle_count`) VALUES
(311001, 1, 9223372036854775806, 311001, 1, 1000, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `ID_transaksi` int(11) NOT NULL,
  `ID_donatur` int(11) DEFAULT NULL,
  `Jumlah` varchar(50) DEFAULT NULL,
  `Status_pembayaran` varchar(100) DEFAULT NULL,
  `Tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`ID_transaksi`, `ID_donatur`, `Jumlah`, `Status_pembayaran`, `Tanggal`) VALUES
(33001, 13348, '12kg', 'Belum Lunas', '2024-04-01'),
(33002, 13349, '2gr', 'Belum Lunas', '2024-04-02'),
(33003, 13350, '15kg', 'Belum Lunas', '2024-04-01'),
(33004, 13351, '6kg', 'Belum Lunas', '2024-03-07'),
(33005, 13352, '9kg', 'Belum Lunas', '2024-04-02');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User_ID` int(11) NOT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `Level` enum('admin','user') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_ID`, `Username`, `Password`, `Level`) VALUES
(1122, 'monika123', '12345678', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `donatur`
--
ALTER TABLE `donatur`
  ADD PRIMARY KEY (`ID_donatur`);

--
-- Indexes for table `penerima`
--
ALTER TABLE `penerima`
  ADD PRIMARY KEY (`ID_penerima`),
  ADD KEY `ID_donatur` (`ID_donatur`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`ID_transaksi`),
  ADD KEY `transaksi_ibfk_1` (`ID_donatur`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `donatur`
--
ALTER TABLE `donatur`
  MODIFY `ID_donatur` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13353;

--
-- AUTO_INCREMENT for table `penerima`
--
ALTER TABLE `penerima`
  MODIFY `ID_penerima` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22003;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `ID_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34786;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44005;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `penerima`
--
ALTER TABLE `penerima`
  ADD CONSTRAINT `penerima_ibfk_1` FOREIGN KEY (`ID_donatur`) REFERENCES `donatur` (`ID_donatur`) ON DELETE SET NULL;

--
-- Constraints for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`ID_donatur`) REFERENCES `donatur` (`ID_donatur`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
