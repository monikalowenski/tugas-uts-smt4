<?php
// FUNCTION CONNECT
$conn = mysqli_connect("localhost", "root", "", "newzakat");
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>